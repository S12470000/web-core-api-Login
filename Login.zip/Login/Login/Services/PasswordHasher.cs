﻿using System.Security.Cryptography;
using Microsoft.AspNetCore.Cryptography.KeyDerivation;

namespace Login.Services
{
    public static class PasswordHasher
    {
        public static string HashPassword(string password)
        {
            // Using PBKDF2
            byte[] salt = new byte[128 / 8];
            using (var rng = RandomNumberGenerator.Create())
            {
                rng.GetBytes(salt);
            }

            string hashed = Convert.ToBase64String(KeyDerivation.Pbkdf2(
                password: password,
                salt: salt,
                prf: KeyDerivationPrf.HMACSHA256,
                iterationCount: 10000,
                numBytesRequested: 256 / 8));

            return $"{Convert.ToBase64String(salt)}.{hashed}";
        }
        public static bool VerifyPassword(string enteredPassword, string storedHash)
        {
            // storedHash format: "salt.hash"
            var parts = storedHash.Split('.');

            if (parts.Length != 2)
                return false; // Invalid format

            // 1️⃣ Extract salt & saved hash
            var saltBytes = Convert.FromBase64String(parts[0]);
            var savedHash = parts[1];

            // 2️⃣ Hash entered password with same salt
            var enteredHash = Convert.ToBase64String(
                KeyDerivation.Pbkdf2(
                    password: enteredPassword,
                    salt: saltBytes,
                    prf: KeyDerivationPrf.HMACSHA256,
                    iterationCount: 10000,
                    numBytesRequested: 256 / 8
                )
            );

            // 3️⃣ Compare hashes
            return enteredHash == savedHash;
        }
    }
}
